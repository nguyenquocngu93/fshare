import assert from "node:assert/strict";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { after, before, describe, it } from "node:test";
import {
  createTorrShelf,
  loadEnvFile,
  resolveLocalServiceUrl,
  deduplicateResults,
  normalizeKnaben,
  normalizeMagnetz,
  normalizeTmdb,
} from "../server.mjs";

const HASH = "DAFC8C076CA2F3ED376EEAE7C76A0D6BE2415C45";
const MAGNET = `magnet:?xt=urn:btih:${HASH}&dn=Ubuntu`;

describe(".env loader", () => {
  it("uses the last duplicate value while preserving real environment variables", () => {
    const dir = mkdtempSync(join(tmpdir(), "torr-shelf-env-"));
    const path = join(dir, ".env");
    const duplicateKey = "TORRSHELF_TEST_DUPLICATE";
    const preservedKey = "TORRSHELF_TEST_PRESERVED";
    delete process.env[duplicateKey];
    process.env[preservedKey] = "from-process";
    writeFileSync(
      path,
      `${duplicateKey}=old\n${duplicateKey}=new\n${preservedKey}=from-file\n`,
    );
    loadEnvFile(path);
    assert.equal(process.env[duplicateKey], "new");
    assert.equal(process.env[preservedKey], "from-process");
    delete process.env[duplicateKey];
    delete process.env[preservedKey];
    rmSync(dir, { recursive: true, force: true });
  });
});

describe("runtime URL correction", () => {
  it("replaces Docker host aliases when running directly on Termux or a desktop", () => {
    const result = resolveLocalServiceUrl("http://host.docker.internal:8090", false);
    assert.equal(result.url.origin, "http://127.0.0.1:8090");
    assert.equal(result.autoCorrected, true);
  });

  it("keeps the Docker host alias from inside a container", () => {
    const result = resolveLocalServiceUrl("http://host.docker.internal:8090", true);
    assert.equal(result.url.origin, "http://host.docker.internal:8090");
    assert.equal(result.autoCorrected, false);
  });
});

describe("normalizers", () => {
  it("normalizes Magnetz results", () => {
    const result = normalizeMagnetz({
      sqid: "abc123",
      name: "Ubuntu ISO",
      info_hash: HASH,
      size: 2_000_000_000,
      seeders: 42,
      leechers: 3,
      magnet_link: MAGNET,
      is_verified: true,
    });
    assert.equal(result.source, "magnetz");
    assert.equal(result.infoHash, HASH);
    assert.equal(result.seeders, 42);
    assert.equal(result.verified, true);
  });

  it("normalizes Knaben results", () => {
    const result = normalizeKnaben({
      id: "k1",
      title: "Ubuntu ISO",
      hash: HASH,
      bytes: 2_000_000_000,
      seeders: 55,
      peers: 4,
      magnetUrl: `${MAGNET}&tr=udp%3A%2F%2Ftracker.example`,
      category: "PC / Unix",
    });
    assert.equal(result.source, "knaben");
    assert.equal(result.seeders, 55);
    assert.match(result.link, /^magnet:/);
  });

  it("normalizes TMDB movies into a torrent search query", () => {
    const result = normalizeTmdb({
      id: 123,
      title: "Tên tiếng Việt",
      original_title: "Original Title",
      release_date: "2026-08-01",
      vote_average: 8.24,
      poster_path: "/poster.jpg",
      backdrop_path: "/backdrop.jpg",
    });
    assert.equal(result.mediaType, "movie");
    assert.equal(result.year, "2026");
    assert.equal(result.rating, 8.2);
    assert.equal(result.searchQuery, "Original Title 2026");
  });

  it("deduplicates by info hash and keeps the richer magnet", () => {
    const magnetz = normalizeMagnetz({
      sqid: "abc123",
      name: "Ubuntu ISO",
      info_hash: HASH,
      size: 2_000_000_000,
      seeders: 42,
      leechers: 3,
      magnet_link: MAGNET,
      is_verified: true,
    });
    const knaben = normalizeKnaben({
      id: "k1",
      title: "Ubuntu ISO",
      hash: HASH,
      bytes: 2_000_000_000,
      seeders: 55,
      peers: 4,
      magnetUrl: `${MAGNET}&tr=udp%3A%2F%2Ftracker.example`,
    });
    const [result] = deduplicateResults([magnetz, knaben]);
    assert.deepEqual(result.sources.sort(), ["knaben", "magnetz"]);
    assert.equal(result.seeders, 55);
    assert.match(result.link, /tracker\.example/);
    assert.equal(result.verified, true);
  });
});

describe("HTTP app", () => {
  let app;
  let baseUrl;
  let addRequest;
  let knabenRequest;

  before(async () => {
    const fakeFetch = async (input, options = {}) => {
      const url = new URL(input);
      if (url.hostname === "magnetz.eu" && url.pathname === "/api/magnets/search") {
        return Response.json({
          data: [
            {
              sqid: "abc123",
              name: "Ubuntu ISO",
              info_hash: HASH,
              size: 2_000_000_000,
              human_size: "1.86 GB",
              seeders: 42,
              leechers: 3,
              magnet_link: MAGNET,
              is_verified: true,
            },
            {
              sqid: "too-big",
              name: "Too big",
              info_hash: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
              size: 40 * 1024 ** 3,
              seeders: 900,
              magnet_link: "magnet:?xt=urn:btih:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            },
          ],
          meta: { total: 2, last_page: 1 },
        });
      }
      if (url.hostname === "api.knaben.org") {
        knabenRequest = JSON.parse(options.body);
        return Response.json({
          total: { value: 1 },
          hits: [
            {
              id: "k1",
              title: "Ubuntu ISO",
              hash: HASH,
              bytes: 2_000_000_000,
              seeders: 55,
              peers: 4,
              magnetUrl: `${MAGNET}&tr=udp%3A%2F%2Ftracker.example`,
              category: "PC / Unix",
            },
          ],
        });
      }
      if (url.hostname === "api.themoviedb.org") {
        if (options.headers?.Authorization) {
          return Response.json(
            { status_message: "Invalid API key: You must be granted a valid key." },
            { status: 401 },
          );
        }
        assert.equal(url.searchParams.get("api_key"), "1234567890abcdef1234567890abcdef");
        if (url.pathname.endsWith("/configuration")) return Response.json({ images: {} });
        if (url.pathname.endsWith("/person/99")) {
          return Response.json({
            id: 99,
            name: "Person One",
            biography: "Tiểu sử",
            birthday: "1980-01-01",
            place_of_birth: "Việt Nam",
            known_for_department: "Acting",
            profile_path: "/person.jpg",
            also_known_as: ["P. One"],
            combined_credits: {
              cast: [{ id: 123, media_type: "movie", title: "Tên phim", original_title: "Original Movie", release_date: "2026-08-01", popularity: 100, character: "Hero" }],
              crew: [],
            },
          });
        }
        if (url.pathname.endsWith("/tv/456/season/1")) {
          return Response.json({
            id: 7001,
            season_number: 1,
            name: "Mùa 1",
            overview: "Nội dung mùa",
            episodes: [
              { id: 8001, season_number: 1, episode_number: 1, name: "Tập đầu", overview: "Nội dung tập", runtime: 52, still_path: "/still.jpg", air_date: "2025-01-01", vote_average: 8 },
            ],
          });
        }
        if (url.pathname.endsWith("/tv/456")) {
          return Response.json({
            id: 456,
            name: "Tên series",
            original_name: "Original Series",
            first_air_date: "2025-01-01",
            overview: "Nội dung series",
            tagline: "Tagline series",
            status: "Returning Series",
            episode_run_time: [52],
            vote_average: 8,
            vote_count: 50,
            poster_path: "/tv-poster.jpg",
            backdrop_path: "/tv-backdrop.jpg",
            original_language: "en",
            genres: [{ id: 18, name: "Chính kịch" }],
            seasons: [{ id: 7001, season_number: 1, name: "Mùa 1", episode_count: 1, overview: "Nội dung mùa", poster_path: "/season.jpg" }],
            number_of_seasons: 1,
            number_of_episodes: 1,
            credits: { cast: [], crew: [] },
            keywords: { results: [] },
            images: { logos: [] },
            videos: { results: [] },
            content_ratings: { results: [{ iso_3166_1: "US", rating: "TV-MA" }] },
            production_companies: [],
          });
        }
        if (url.pathname.endsWith("/movie/123")) {
          return Response.json({
            id: 123,
            title: "Tên phim",
            original_title: "Original Movie",
            release_date: "2026-08-01",
            overview: "Nội dung đầy đủ",
            tagline: "Một tagline",
            status: "Released",
            runtime: 125,
            vote_average: 8.1,
            vote_count: 100,
            poster_path: "/poster.jpg",
            backdrop_path: "/backdrop.jpg",
            original_language: "en",
            genres: [{ id: 28, name: "Hành động" }],
            credits: {
              cast: [{ id: 10, name: "Actor One", character: "Hero", profile_path: "/actor.jpg" }],
              crew: [{ id: 11, name: "Director One", job: "Director", department: "Directing" }],
            },
            keywords: { keywords: [{ id: 1, name: "adventure" }] },
            images: { logos: [{ file_path: "/logo.png", iso_639_1: "en", vote_average: 5 }] },
            videos: { results: [{ site: "YouTube", key: "abc", type: "Trailer", official: true }] },
            release_dates: { results: [{ iso_3166_1: "VN", release_dates: [{ certification: "C16" }] }] },
            production_companies: [{ id: 20, name: "Studio", logo_path: "/studio.png", origin_country: "US" }],
          });
        }
        const isTv = url.pathname.includes("/tv/");
        return Response.json({
          page: 1,
          total_pages: 3,
          total_results: 55,
          results: [
            {
              id: isTv ? 456 : 123,
              media_type: isTv ? "tv" : "movie",
              title: isTv ? undefined : "Tên phim",
              original_title: isTv ? undefined : "Original Movie",
              name: isTv ? "Tên series" : undefined,
              original_name: isTv ? "Original Series" : undefined,
              release_date: isTv ? undefined : "2026-08-01",
              first_air_date: isTv ? "2025-01-01" : undefined,
              overview: "Mô tả",
              vote_average: 8.1,
              vote_count: 100,
              poster_path: "/poster.jpg",
              backdrop_path: "/backdrop.jpg",
              adult: false,
            },
            ...(url.pathname.endsWith("/search/multi") ? [{
              id: 99,
              media_type: "person",
              name: "Person One",
              known_for_department: "Acting",
              profile_path: "/person.jpg",
              popularity: 50,
              known_for: [],
            }] : []),
          ],
        });
      }
      if (url.hostname === "torrserver.test" && url.pathname === "/echo") {
        return new Response("MatriX.142.2", { status: 200 });
      }
      if (url.hostname === "torrserver.test" && url.pathname === "/stream/status") {
        return Response.json({
          hash: HASH.toLowerCase(),
          stat: 2,
          stat_string: "Torrent preload",
          preload_size: 64_000_000,
          preloaded_bytes: 16_000_000,
          download_speed: 4_000_000,
          active_peers: 6,
          total_peers: 20,
          connected_seeders: 3,
          file_stats: [{ id: 1, path: "ubuntu.iso.mp4", length: 2_000_000_000 }],
        });
      }
      if (url.hostname === "torrserver.test" && url.pathname === "/torrents") {
        const request = JSON.parse(options.body);
        if (request.action === "list") {
          return Response.json([
            {
              hash: HASH.toLowerCase(),
              title: "Ubuntu ISO",
              torrent_size: 2_000_000_000,
              loaded_size: 500_000_000,
              download_speed: 5_000_000,
              active_peers: 8,
              total_peers: 25,
              connected_seeders: 4,
              stat: 3,
              stat_string: "Torrent working",
              file_stats: [{ id: 1, path: "ubuntu.iso.mp4", length: 2_000_000_000 }],
            },
          ]);
        }
        addRequest = request;
        return Response.json({ hash: HASH.toLowerCase(), stat: 0, stat_string: "Torrent added" });
      }
      throw new Error(`Unexpected fetch: ${url}`);
    };

    app = createTorrShelf({
      torrServerUrl: "http://torrserver.test:8090",
      torrServerPublicUrl: "http://127.0.0.1:8090",
      tmdbToken: "test-token-that-must-not-leak",
      tmdbApiKey: "1234567890abcdef1234567890abcdef",
      fetchImpl: fakeFetch,
    });
    await new Promise((resolve) => app.server.listen(0, "127.0.0.1", resolve));
    const address = app.server.address();
    baseUrl = `http://127.0.0.1:${address.port}`;
  });

  after(async () => {
    await new Promise((resolve, reject) => app.server.close((error) => (error ? reject(error) : resolve())));
  });

  it("cache-busts frontend assets and forces JS/CSS revalidation", async () => {
    const htmlResponse = await fetch(`${baseUrl}/`);
    const html = await htmlResponse.text();
    assert.match(html, /ui\.css\?v=0\.11\.0/);
    assert.match(html, /app\.js\?v=0\.11\.0/);
    assert.doesNotMatch(html, /styles\.css/);
    assert.ok(
      html.indexOf('</header>') < html.indexOf('<nav class="app-nav"'),
      "bottom navigation must remain outside the glass header containing block",
    );
    assert.match(htmlResponse.headers.get("cache-control"), /no-store/);

    const cssResponse = await fetch(`${baseUrl}/ui.css?v=0.11.0`);
    assert.equal(cssResponse.status, 200);
    assert.match(cssResponse.headers.get("cache-control"), /no-store/);
    const css = await cssResponse.text();
    assert.match(css, /\.topbar\s*\{[\s\S]*?position:\s*sticky/);
    assert.match(css, /\.app-nav\s*\{[\s\S]*?backdrop-filter:\s*blur\(30px\)/);
    assert.match(css, /\.manage-torrent\s*\{/);
    assert.match(css, /\.media-sheet\s*\{/);
  });

  it("reports TorrServer health", async () => {
    const response = await fetch(`${baseUrl}/api/health`);
    const payload = await response.json();
    assert.equal(payload.torrServer.online, true);
    assert.equal(payload.torrServer.version, "MatriX.142.2");
    assert.equal(payload.sizeFilter.userControlled, true);
    assert.equal(payload.sizeFilter.emptyMeansUnlimited, true);
    assert.equal(payload.tmdb.configured, true);
    assert.doesNotMatch(JSON.stringify(payload), /test-token-that-must-not-leak/);
    assert.doesNotMatch(JSON.stringify(payload), /1234567890abcdef1234567890abcdef/);
  });

  it("loads the TorrServer library", async () => {
    const response = await fetch(`${baseUrl}/api/torrserver/torrents`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.data.length, 1);
    assert.equal(payload.data[0].title, "Ubuntu ISO");
  });

  it("loads the TMDB home rails without exposing credentials", async () => {
    const response = await fetch(`${baseUrl}/api/tmdb/home`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.ok(payload.hero);
    assert.equal(payload.rails.length, 6);
    assert.equal(payload.rails[0].items[0].searchQuery, "Original Movie 2026");
    assert.equal(payload.meta.credentialMode, "api_key_v3");
    assert.doesNotMatch(JSON.stringify(payload), /test-token-that-must-not-leak/);
    assert.doesNotMatch(JSON.stringify(payload), /1234567890abcdef1234567890abcdef/);
  });

  it("paginates a TMDB rail", async () => {
    const response = await fetch(`${baseUrl}/api/tmdb/list?key=popularMovies&page=1`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.title, "Phim phổ biến");
    assert.equal(payload.totalPages, 3);
    assert.equal(payload.items[0].id, 123);
  });

  it("searches TMDB media and people", async () => {
    const response = await fetch(`${baseUrl}/api/tmdb/search?q=person&page=1`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.items[0].id, 123);
    assert.equal(payload.people[0].name, "Person One");
  });

  it("builds internal genre and tag collections", async () => {
    const response = await fetch(`${baseUrl}/api/tmdb/discover?kind=genre&id=28&label=Action&media=movie&page=1`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.title, "Thể loại: Action");
    assert.equal(payload.items[0].id, 123);
  });

  it("returns an internal person profile and filmography", async () => {
    const response = await fetch(`${baseUrl}/api/tmdb/person/99`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.data.name, "Person One");
    assert.equal(payload.data.filmography[0].creditRole, "Hero");
    assert.equal(payload.data.movieCredits.length, 1);
    assert.equal(payload.data.tvCredits.length, 0);
  });

  it("returns full TMDB metadata for a detail page", async () => {
    const response = await fetch(`${baseUrl}/api/tmdb/movie/123`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.data.runtime, 125);
    assert.equal(payload.data.certification, "C16");
    assert.equal(payload.data.directors[0].name, "Director One");
    assert.equal(payload.data.cast[0].character, "Hero");
    assert.deepEqual(payload.data.keywords[0], { id: 1, name: "adventure" });
    assert.equal(payload.data.logoPath, "/logo.png");
  });

  it("returns TV seasons and episode metadata", async () => {
    const detailResponse = await fetch(`${baseUrl}/api/tmdb/tv/456`);
    const detail = await detailResponse.json();
    assert.equal(detailResponse.status, 200);
    assert.equal(detail.data.seasons[0].seasonNumber, 1);
    assert.equal(detail.data.seasons[0].episodeCount, 1);

    const seasonResponse = await fetch(`${baseUrl}/api/tmdb/tv/456/season/1`);
    const season = await seasonResponse.json();
    assert.equal(seasonResponse.status, 200);
    assert.equal(season.data.episodes[0].episodeNumber, 1);
    assert.equal(season.data.episodes[0].runtime, 52);
    assert.equal(season.data.episodes[0].stillPath, "/still.jpg");
  });

  it("merges duplicate results and filters torrents over 30 GB", async () => {
    const response = await fetch(`${baseUrl}/api/search?q=ubuntu&source=all&maxGb=30&minSeeds=1`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.data.length, 1);
    assert.deepEqual(payload.data[0].sources.sort(), ["knaben", "magnetz"]);
    assert.ok(payload.data[0].ref);
  });

  it("passes the selected size sorting to Knaben instead of sorting only a seeders page", async () => {
    const response = await fetch(`${baseUrl}/api/search?q=house%20of%20the%20dragon&source=knaben&sort=size-desc&maxGb=&minSeeds=0`);
    assert.equal(response.status, 200);
    assert.equal(knabenRequest.order_by, "bytes");
    assert.equal(knabenRequest.order_direction, "desc");
  });

  it("has no hard size limit when the user leaves the filter blank", async () => {
    const response = await fetch(`${baseUrl}/api/search?q=ubuntu&source=magnetz&maxGb=&minSeeds=0`);
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.ok(payload.data.some((item) => item.title === "Too big"));
    assert.equal(payload.meta.maxSizeGb, null);
  });

  it("manages torrents through drop/remove actions", async () => {
    const response = await fetch(`${baseUrl}/api/torrserver/action`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "drop", hash: HASH.toLowerCase() }),
    });
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.ok, true);
    assert.equal(payload.action, "drop");

    const activateResponse = await fetch(`${baseUrl}/api/torrserver/action`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "preload", hash: HASH.toLowerCase(), fileId: 1 }),
    });
    const activated = await activateResponse.json();
    assert.equal(activateResponse.status, 200);
    assert.equal(activated.torrent.stat_string, "Torrent preload");
    assert.equal(activated.torrent.active_peers, 6);
  });

  it("adds a cached search result to TorrServer", async () => {
    const searchResponse = await fetch(`${baseUrl}/api/search?q=ubuntu&source=all&maxGb=30&minSeeds=1`);
    const search = await searchResponse.json();
    const response = await fetch(`${baseUrl}/api/torrserver/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ref: search.data[0].ref,
        tmdb: {
          id: 123,
          mediaType: "movie",
          title: "Tên phim",
          originalTitle: "Original Movie",
          year: "2026",
          posterPath: "/poster.jpg",
          backdropPath: "/backdrop.jpg",
        },
      }),
    });
    const payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.ok, true);
    assert.equal(addRequest.action, "add");
    assert.equal(addRequest.save_to_db, true);
    assert.match(addRequest.link, /^magnet:/);
    assert.match(addRequest.poster, /image\.tmdb\.org\/t\/p\/w500\/poster\.jpg/);
    assert.equal(JSON.parse(addRequest.data).TorrShelf.tmdb.id, 123);
  });
});
