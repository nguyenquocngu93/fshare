const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const elements = {
  form: $("#searchForm"),
  input: $("#searchInput"),
  maxSize: $("#maxSizeInput"),
  minSeeds: $("#minSeedsInput"),
  sort: $("#sortSelect"),
  hideXxx: $("#hideXxxInput"),
  results: $("#results"),
  skeletons: $("#skeletons"),
  empty: $("#emptyState"),
  header: $("#resultsHeader"),
  title: $("#resultTitle"),
  kicker: $("#resultKicker"),
  meta: $("#searchMeta"),
  notice: $("#notice"),
  pagination: $("#pagination"),
  prev: $("#prevButton"),
  next: $("#nextButton"),
  pageLabel: $("#pageLabel"),
  serverDot: $("#serverDot"),
  serverLabel: $("#serverLabel"),
  serverLink: $("#torrServerLink"),
  continueSection: $("#continueSection"),
  continueRow: $("#continueRow"),
  libraryView: $("#libraryView"),
  libraryBackButton: $("#libraryBackButton"),
  libraryRefreshButton: $("#libraryRefreshButton"),
  libraryPageLoading: $("#libraryPageLoading"),
  libraryGrid: $("#libraryGrid"),
  libraryEmpty: $("#libraryEmpty"),
  libraryContinueSection: $("#libraryContinueSection"),
  libraryContinueRow: $("#libraryContinueRow"),
  libraryItemView: $("#libraryItemView"),
  libraryItemBackButton: $("#libraryItemBackButton"),
  libraryItemContent: $("#libraryItemContent"),
  playerView: $("#playerView"),
  playerBackButton: $("#playerBackButton"),
  playerTitle: $("#playerTitle"),
  playerSubtitle: $("#playerSubtitle"),
  videoPlayer: $("#videoPlayer"),
  playerError: $("#playerError"),
  playerFileName: $("#playerFileName"),
  openDirectStream: $("#openDirectStream"),
  openVlc: $("#openVlc"),
  toastRegion: $("#toastRegion"),
  limitText: $("#limitText"),
  pageBackdrop: $("#pageBackdrop"),
  pageBackdropImage: $("#pageBackdropImage"),
  discoverView: $("#discoverView"),
  searchView: $("#searchView"),
  discoverLoading: $("#discoverLoading"),
  discoverContent: $("#discoverContent"),
  tmdbSearchForm: $("#tmdbSearchForm"),
  tmdbSearchInput: $("#tmdbSearchInput"),
  tmdbSetup: $("#tmdbSetup"),
  setupSearchButton: $("#setupSearchButton"),
  featuredHero: $("#featuredHero"),
  railsContainer: $("#railsContainer"),
  browseView: $("#browseView"),
  browseBackButton: $("#browseBackButton"),
  browseTitle: $("#browseTitle"),
  browseSubtitle: $("#browseSubtitle"),
  browseCount: $("#browseCount"),
  browseLoading: $("#browseLoading"),
  browseGrid: $("#browseGrid"),
  browsePeopleSection: $("#browsePeopleSection"),
  browsePeopleGrid: $("#browsePeopleGrid"),
  browsePrev: $("#browsePrev"),
  browseNext: $("#browseNext"),
  browsePageLabel: $("#browsePageLabel"),
  mediaPageView: $("#mediaPageView"),
  mediaBackButton: $("#mediaBackButton"),
  mediaPageLoading: $("#mediaPageLoading"),
  mediaPageContent: $("#mediaPageContent"),
  personView: $("#personView"),
  personBackButton: $("#personBackButton"),
  personLoading: $("#personLoading"),
  personContent: $("#personContent"),
};

const state = {
  view: "discover",
  query: "",
  source: "all",
  page: 1,
  maxPages: 1,
  hasNextPage: false,
  results: [],
  loading: false,
  controller: null,
  health: null,
  libraryHashes: new Set(),
  discoverLoaded: false,
  mediaItems: new Map(),
  selectedMedia: null,
  browseKey: "",
  browseMode: "rail",
  browseParams: {},
  browsePage: 1,
  browseTotalPages: 1,
  previousView: "discover",
  selectedPerson: null,
  selectedSeason: null,
  personTab: "movie",
  personPage: 1,
  torrentContext: null,
  libraryItems: new Map(),
  selectedTorrent: null,
  selectedFile: null,
  torrServerPublicUrl: "http://127.0.0.1:8090",
  lastProgressSave: 0,
  libraryPollTimer: null,
};

try {
  state.torrentContext = JSON.parse(sessionStorage.getItem("torrshelf.torrentContext") || "null");
} catch {
  state.torrentContext = null;
}

const icons = {
  database: '<svg viewBox="0 0 24 24" aria-hidden="true"><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>',
  users: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3.5 19c.5-3.2 2.3-5 5.5-5s5 1.8 5.5 5M16 5.5a3 3 0 0 1 0 5.8M16 14c2.6.2 4 1.8 4.5 4.2"/></svg>',
  verified: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 12 2.7 2.7L16.5 9M12 3l2.1 1.6 2.6-.1.7 2.5 2.2 1.4-.9 2.5.9 2.5-2.2 1.4-.7 2.5-2.6-.1L12 19l-2.1-1.8-2.6.1-.7-2.5-2.2-1.4.9-2.5-.9-2.5L6.6 7l.7-2.5 2.6.1z"/></svg>',
  copy: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 9h10v10H9zM5 15V5h10"/></svg>',
  external: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 5h5v5M19 5l-8 8M19 14v5H5V5h5"/></svg>',
  plus: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>',
  star: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9z"/></svg>',
  film: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v14H4zM8 5v14M16 5v14M4 9h4M4 15h4M16 9h4M16 15h4"/></svg>',
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatBytes(bytes) {
  const value = Number(bytes) || 0;
  if (!value) return "Không rõ";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
  const amount = value / 1024 ** index;
  return `${amount >= 10 || index === 0 ? amount.toFixed(0) : amount.toFixed(1)} ${units[index]}`;
}

function formatDate(value) {
  if (!value) return "Không rõ ngày";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Không rõ ngày";
  const days = Math.round((Date.now() - date.getTime()) / 86_400_000);
  if (days === 0) return "Hôm nay";
  if (days === 1) return "Hôm qua";
  if (days > 1 && days < 30) return `${days} ngày trước`;
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
}

function safeExternalUrl(value) {
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) ? url.href : "#";
  } catch {
    return "#";
  }
}

function tmdbImage(path, size = "w500") {
  return path ? `/api/tmdb/image?path=${encodeURIComponent(path)}&size=${encodeURIComponent(size)}` : "";
}

function mediaKey(item) {
  return `${item.mediaType}:${item.id}`;
}

function mediaTypeLabel(type) {
  return type === "tv" ? "Series" : "Phim";
}

function switchView(view, options = {}) {
  const allowed = ["discover", "search", "browse", "media", "person", "library", "libraryItem", "player"];
  state.view = allowed.includes(view) ? view : "discover";
  elements.discoverView.classList.toggle("hidden", state.view !== "discover");
  elements.searchView.classList.toggle("hidden", state.view !== "search");
  elements.browseView.classList.toggle("hidden", state.view !== "browse");
  elements.mediaPageView.classList.toggle("hidden", state.view !== "media");
  elements.personView.classList.toggle("hidden", state.view !== "person");
  elements.libraryView.classList.toggle("hidden", state.view !== "library");
  elements.libraryItemView.classList.toggle("hidden", state.view !== "libraryItem");
  elements.playerView.classList.toggle("hidden", state.view !== "player");
  if (state.view !== "player" && !elements.videoPlayer.paused) elements.videoPlayer.pause();
  $$(".nav-button").forEach((button) => {
    const navView = state.view === "search"
      ? "search"
      : ["library", "libraryItem", "player"].includes(state.view)
        ? "manage"
        : "discover";
    button.classList.toggle("active", button.dataset.view === navView);
  });
  if (state.view === "discover" && !state.discoverLoaded && state.health?.tmdb?.configured) loadDiscover();
  if (options.focusSearch) setTimeout(() => elements.input.focus(), 50);
  window.scrollTo({ top: 0, behavior: options.instant ? "auto" : "smooth" });
}

function writeRoute(params = {}, { replace = false } = {}) {
  const url = new URL(window.location.origin + window.location.pathname);
  for (const [key, value] of Object.entries(params)) {
    if (value != null && value !== "") url.searchParams.set(key, String(value));
  }
  const currentDepth = Number(history.state?.depth) || 0;
  const depth = replace ? currentDepth : currentDepth + 1;
  history[replace ? "replaceState" : "pushState"]({ torrShelf: true, depth }, "", url);
}

function goDiscover(options = {}) {
  switchView("discover", options);
  if (options.history !== false) writeRoute({}, { replace: options.replace });
}

function goSearchView(options = {}) {
  switchView("search", { ...options, focusSearch: options.focusSearch ?? true });
  if (options.history !== false) writeRoute({ view: "search" }, { replace: options.replace });
}

function posterMarkup(item, size = "w500") {
  if (!item.posterPath) return `<span class="poster-placeholder">${icons.film}</span>`;
  return `<img src="${tmdbImage(item.posterPath, size)}" alt="Poster ${escapeHtml(item.title)}" loading="lazy" />`;
}

function mediaMetaMarkup(item) {
  return `
    <span class="media-type-chip">${mediaTypeLabel(item.mediaType)}</span>
    ${item.year ? `<span>${escapeHtml(item.year)}</span>` : ""}
    <span class="rating-chip">${icons.star}${Number(item.rating || 0).toFixed(1)}</span>
    ${item.originalLanguage ? `<span>${escapeHtml(item.originalLanguage.toUpperCase())}</span>` : ""}
  `;
}

function renderFeatured(item) {
  if (!item) return "";
  const key = mediaKey(item);
  const backdrop = item.backdropPath
    ? `<div class="featured-backdrop"><img src="${tmdbImage(item.backdropPath, "w1280")}" alt="" /></div>`
    : "";
  return `
    ${backdrop}
    <div class="featured-copy">
      <span class="featured-label">Nổi bật trên TMDB</span>
      <h1>${escapeHtml(item.title)}</h1>
      <div class="featured-meta">${mediaMetaMarkup(item)}</div>
      <p class="featured-overview">${escapeHtml(item.overview || "Chưa có mô tả tiếng Việt cho tựa phim này.")}</p>
      <div class="featured-actions">
        <button class="button primary" data-find-media="${escapeHtml(key)}" type="button">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" /><path d="m15.5 15.5 4.5 4.5" /></svg>
          Tìm bản torrent
        </button>
        <button class="button ghost" data-open-media="${escapeHtml(key)}" type="button">Xem nội dung</button>
      </div>
    </div>
  `;
}

function mediaCard(item) {
  const key = mediaKey(item);
  return `
    <article class="media-card">
      <button class="poster-button" data-open-media="${escapeHtml(key)}" type="button" aria-label="Xem ${escapeHtml(item.title)}">
        ${posterMarkup(item)}
        <span class="poster-find">${icons.plus} Xem & tìm</span>
      </button>
      <div class="media-card-copy">
        <h3 title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</h3>
        <div>
          <span title="${escapeHtml(item.creditRole || "")}">${escapeHtml(item.creditRole || item.year || mediaTypeLabel(item.mediaType))}</span>
          <span class="rating-chip">${icons.star}${Number(item.rating || 0).toFixed(1)}</span>
        </div>
      </div>
    </article>
  `;
}

function renderDiscover(payload) {
  state.mediaItems.clear();
  for (const rail of payload.rails || []) {
    for (const item of rail.items || []) state.mediaItems.set(mediaKey(item), item);
  }
  if (payload.hero) state.mediaItems.set(mediaKey(payload.hero), payload.hero);

  elements.featuredHero.innerHTML = renderFeatured(payload.hero);
  if (payload.hero?.backdropPath) {
    elements.pageBackdropImage.src = tmdbImage(payload.hero.backdropPath, "w1280");
    elements.pageBackdrop.classList.add("visible");
  }
  elements.railsContainer.innerHTML = (payload.rails || [])
    .map(
      (rail) => `
        <section class="media-rail" aria-labelledby="rail-${escapeHtml(rail.key)}">
          <div class="rail-head">
            <div>
              <h2 id="rail-${escapeHtml(rail.key)}">${escapeHtml(rail.title)}</h2>
              <p>${escapeHtml(rail.subtitle)}</p>
            </div>
            <div class="rail-actions">
              <span class="rail-count">${rail.items.length} tựa</span>
              <button class="rail-more" data-browse-key="${escapeHtml(rail.key)}" type="button">
                Xem thêm
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6" /></svg>
              </button>
            </div>
          </div>
          <div class="poster-row">${rail.items.map(mediaCard).join("")}</div>
        </section>
      `,
    )
    .join("");
  elements.discoverLoading.classList.add("hidden");
  elements.tmdbSetup.classList.add("hidden");
  elements.discoverContent.classList.remove("hidden");
  state.discoverLoaded = true;
  renderContinueWatching();

  if (payload.meta?.errors?.length) {
    toast("TMDB trả dữ liệu một phần", "Một số danh mục chưa tải được; các mục còn lại vẫn dùng bình thường.", "error");
  }
}

async function loadDiscover() {
  elements.discoverLoading.classList.remove("hidden");
  elements.discoverContent.classList.add("hidden");
  elements.tmdbSetup.classList.add("hidden");
  try {
    const payload = await api("/api/tmdb/home");
    renderDiscover(payload);
  } catch (error) {
    elements.discoverLoading.classList.add("hidden");
    if (error.payload?.code === "tmdb_not_configured") {
      elements.tmdbSetup.classList.remove("hidden");
    } else {
      elements.tmdbSetup.classList.remove("hidden");
      elements.tmdbSetup.querySelector("h1").textContent = "Không tải được TMDB";
      elements.tmdbSetup.querySelector("p").textContent =
        error.payload?.sources?.[0]?.message || error.message;
    }
  }
}

function personSearchCard(person) {
  return `
    <button class="person-search-card" data-person-id="${person.id}" type="button">
      <div class="person-photo">${personPhoto(person, "w300")}</div>
      <h3 title="${escapeHtml(person.name)}">${escapeHtml(person.name)}</h3>
      <p>${escapeHtml(person.knownForDepartment || "Nhân vật")}</p>
    </button>
  `;
}

function renderBrowsePayload(payload) {
  state.browseTotalPages = payload.totalPages || 1;
  for (const item of payload.items || []) state.mediaItems.set(mediaKey(item), item);
  elements.browseTitle.textContent = payload.title || `Kết quả cho “${state.browseParams.query || ""}”`;
  elements.browseSubtitle.textContent = payload.subtitle || "Phim, series và nhân vật trên TMDB";
  elements.browseCount.textContent = `${Number(payload.totalResults || 0).toLocaleString("vi-VN")} kết quả`;
  elements.browseGrid.innerHTML = (payload.items || []).map(mediaCard).join("")
    || '<div class="notice">Không có phim hoặc series phù hợp.</div>';
  const people = payload.people || [];
  elements.browsePeopleSection.classList.toggle("hidden", !people.length);
  elements.browsePeopleGrid.innerHTML = people.map(personSearchCard).join("");
  elements.browsePageLabel.textContent = `Trang ${payload.page} / ${payload.totalPages}`;
  elements.browsePrev.disabled = payload.page <= 1;
  elements.browseNext.disabled = payload.page >= payload.totalPages;
}

async function loadCurrentBrowse(page = state.browsePage) {
  state.browsePage = page;
  elements.browseGrid.innerHTML = "";
  elements.browsePeopleSection.classList.add("hidden");
  elements.browseLoading.innerHTML = Array.from({ length: 18 }, () => '<i class="browse-skeleton"></i>').join("");
  elements.browseLoading.classList.remove("hidden");
  try {
    let endpoint;
    if (state.browseMode === "search") {
      endpoint = `/api/tmdb/search?q=${encodeURIComponent(state.browseParams.query)}&page=${page}`;
    } else if (state.browseMode === "discover") {
      const params = new URLSearchParams({
        kind: state.browseParams.kind,
        id: String(state.browseParams.id),
        label: state.browseParams.label,
        media: state.browseParams.media,
        page: String(page),
      });
      endpoint = `/api/tmdb/discover?${params}`;
    } else {
      endpoint = `/api/tmdb/list?key=${encodeURIComponent(state.browseKey)}&page=${page}`;
    }
    const payload = await api(endpoint);
    renderBrowsePayload(payload);
  } catch (error) {
    elements.browseGrid.innerHTML = `<div class="notice">${escapeHtml(error.message)}</div>`;
  } finally {
    elements.browseLoading.classList.add("hidden");
  }
}

async function openBrowse(key, page = 1, options = {}) {
  state.previousView = "discover";
  state.browseMode = "rail";
  state.browseKey = key;
  state.browseParams = {};
  switchView("browse", { instant: true });
  if (options.history !== false) {
    writeRoute({ view: "browse", category: key, page }, { replace: options.replace });
  }
  await loadCurrentBrowse(page);
}

async function openTmdbSearch(query, page = 1, options = {}) {
  const cleaned = String(query || "").trim();
  if (cleaned.length < 2) return;
  state.previousView = "discover";
  state.browseMode = "search";
  state.browseParams = { query: cleaned };
  switchView("browse", { instant: true });
  if (options.history !== false) {
    writeRoute({ view: "browse", tmdbq: cleaned, page }, { replace: options.replace });
  }
  await loadCurrentBrowse(page);
}

async function openDiscoverFilter(kind, id, label, media = "movie", page = 1, options = {}) {
  state.previousView = "media";
  state.browseMode = "discover";
  state.browseParams = { kind, id, label, media };
  switchView("browse", { instant: true });
  if (options.history !== false) {
    writeRoute(
      { view: "browse", kind, id, label, type: media, page },
      { replace: options.replace },
    );
  }
  await loadCurrentBrowse(page);
}

function formatRuntime(minutes) {
  const value = Number(minutes) || 0;
  if (!value) return "";
  const hours = Math.floor(value / 60);
  const rest = value % 60;
  return hours ? `${hours} giờ ${rest ? `${rest} phút` : ""}`.trim() : `${rest} phút`;
}

function formatMoney(value) {
  const amount = Number(value) || 0;
  if (!amount) return "Không công bố";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(amount);
}

function personPhoto(person, size = "w185") {
  return person.profilePath
    ? `<img src="${tmdbImage(person.profilePath, size)}" alt="${escapeHtml(person.name)}" loading="lazy" />`
    : `<span class="poster-placeholder">${icons.users}</span>`;
}

function renderMediaDetail(item) {
  const runtime = formatRuntime(item.runtime);
  const detailChips = [
    item.year,
    runtime,
    item.certification,
    item.mediaType === "tv" && item.numberOfSeasons ? `${item.numberOfSeasons} mùa` : "",
    item.mediaType === "tv" && item.numberOfEpisodes ? `${item.numberOfEpisodes} tập` : "",
  ].filter(Boolean);
  const seasons = item.seasons || [];
  if (item.mediaType === "tv" && seasons.length && state.selectedSeason == null) {
    state.selectedSeason = seasons.find((season) => season.seasonNumber > 0)?.seasonNumber
      ?? seasons[0].seasonNumber;
  }
  const backdrop = item.backdropPath
    ? `<div class="detail-backdrop"><img src="${tmdbImage(item.backdropPath, "w1280")}" alt="" /></div>`
    : "";
  const logo = item.logoPath
    ? `<img class="detail-logo" src="${tmdbImage(item.logoPath, "w500")}" alt="Logo ${escapeHtml(item.title)}" />`
    : "";
  const directors = item.directors.length
    ? item.directors.map((person) => `
      <button class="director-card" data-person-id="${person.id}" type="button">
        <div class="person-photo">${personPhoto(person)}</div>
        <div><h3>${escapeHtml(person.name)}</h3><p>${escapeHtml(person.job)}</p></div>
      </button>`).join("")
    : '<p class="media-original">Chưa có thông tin đạo diễn.</p>';
  const cast = item.cast.length
    ? item.cast.map((person) => `
      <button class="person-card" data-person-id="${person.id}" type="button">
        <div class="person-photo">${personPhoto(person, "w300")}</div>
        <h3 title="${escapeHtml(person.name)}">${escapeHtml(person.name)}</h3>
        <p title="${escapeHtml(person.character)}">${escapeHtml(person.character || "Diễn viên")}</p>
      </button>`).join("")
    : '<p class="media-original">Chưa có dữ liệu diễn viên.</p>';
  const companies = item.productionCompanies.length
    ? item.productionCompanies.map((company) => `
      <button class="company-card" data-discover-kind="company" data-discover-id="${company.id}" data-discover-label="${escapeHtml(company.name)}" data-discover-media="${item.mediaType}" type="button">
        ${company.logoPath ? `<img src="${tmdbImage(company.logoPath, "w185")}" alt="" />` : ""}
        <span>${escapeHtml(company.name)}</span>
      </button>`).join("")
    : '<p class="media-original">Không có dữ liệu.</p>';
  return `
    <section class="media-visual">
      ${backdrop}
      <div class="media-visual-shade"></div>
      <div class="media-visual-title">
        ${logo || `<h1>${escapeHtml(item.title)}</h1>`}
      </div>
    </section>
    <section class="media-sheet">
      <div class="media-sheet-grid">
        <div class="detail-poster">${posterMarkup(item, "w300")}</div>
        <div class="media-sheet-copy">
          ${logo ? `<h1 class="detail-title">${escapeHtml(item.title)}</h1>` : ""}
          ${item.originalTitle !== item.title ? `<p class="media-original">${escapeHtml(item.originalTitle)}</p>` : ""}
          <div class="featured-meta">${mediaMetaMarkup(item)}</div>
          ${item.tagline ? `<p class="detail-tagline">“${escapeHtml(item.tagline)}”</p>` : ""}
          <div class="detail-chips">
            ${detailChips.map((value) => `<span class="detail-chip">${escapeHtml(value)}</span>`).join("")}
            ${item.genres.map((genre) => `<button class="detail-chip" data-discover-kind="genre" data-discover-id="${genre.id}" data-discover-label="${escapeHtml(genre.name)}" data-discover-media="${item.mediaType}" type="button">${escapeHtml(genre.name)}</button>`).join("")}
          </div>
          <p class="detail-overview-short">${escapeHtml(item.overview || "Chưa có nội dung tiếng Việt.")}</p>
          <div class="detail-actions">
            <button class="button primary" data-detail-find type="button">${icons.plus} Tìm bản torrent</button>
            ${item.trailerUrl ? `<a class="button ghost" href="${escapeHtml(safeExternalUrl(item.trailerUrl))}" target="_blank" rel="noreferrer">Xem trailer</a>` : ""}
          </div>
        </div>
      </div>
    </section>
    <div class="detail-body">
      <div>
        <section class="detail-section">
          <div class="detail-section-head"><h2>Nội dung phim</h2><span>${mediaTypeLabel(item.mediaType)}</span></div>
          <p class="detail-synopsis">${escapeHtml(item.overview || "Chưa có nội dung tiếng Việt cho tựa phim này.")}</p>
        </section>
        <section class="detail-section">
          <div class="detail-section-head"><h2>Đạo diễn & sáng tạo</h2></div>
          <div class="director-list">${directors}</div>
        </section>
        <section class="detail-section">
          <div class="detail-section-head"><h2>Diễn viên</h2><span>${item.cast.length} người</span></div>
          <div class="people-grid">${cast}</div>
        </section>
        ${item.keywords.length ? `<section class="detail-section"><div class="detail-section-head"><h2>Tag & từ khóa</h2></div><div class="detail-tags">${item.keywords.map((keyword) => `<button class="detail-tag" data-discover-kind="keyword" data-discover-id="${keyword.id}" data-discover-label="${escapeHtml(keyword.name)}" data-discover-media="${item.mediaType}" type="button">#${escapeHtml(keyword.name)}</button>`).join("")}</div></section>` : ""}
      </div>
      <aside>
        <section class="detail-section">
          <div class="detail-section-head"><h2>Thông tin</h2></div>
          <div class="detail-facts">
            <div class="fact-row"><span>Trạng thái</span><strong>${escapeHtml(item.status || "Không rõ")}</strong></div>
            <div class="fact-row"><span>Ngày phát hành</span><strong>${escapeHtml(item.date || "Không rõ")}</strong></div>
            <div class="fact-row"><span>Phân loại</span><strong>${escapeHtml(item.certification || "Chưa có")}</strong></div>
            <div class="fact-row"><span>Thời lượng</span><strong>${escapeHtml(runtime || "Không rõ")}</strong></div>
            <div class="fact-row"><span>Ngôn ngữ gốc</span><strong>${escapeHtml((item.originalLanguage || "—").toUpperCase())}</strong></div>
            ${item.mediaType === "movie" ? `<div class="fact-row"><span>Ngân sách</span><strong>${escapeHtml(formatMoney(item.budget))}</strong></div><div class="fact-row"><span>Doanh thu</span><strong>${escapeHtml(formatMoney(item.revenue))}</strong></div>` : ""}
          </div>
        </section>
        <section class="detail-section">
          <div class="detail-section-head"><h2>Hãng sản xuất</h2></div>
          <div class="company-list">${companies}</div>
        </section>
      </aside>
    </div>
    ${item.mediaType === "tv" && seasons.length ? `
      <section class="episodes-hub glass-panel">
        <div class="episodes-toolbar">
          <div>
            <span class="dialog-kicker">EPISODE GUIDE</span>
            <h2>Tập phim</h2>
          </div>
          <div class="season-actions">
            <label>
              <span>Mùa</span>
              <select id="seasonSelect" aria-label="Chọn mùa">
                ${seasons.map((season) => `<option value="${season.seasonNumber}" ${season.seasonNumber === state.selectedSeason ? "selected" : ""}>${escapeHtml(season.seasonNumber === 0 ? season.name || "Đặc biệt" : `Mùa ${season.seasonNumber}`)} · ${season.episodeCount} tập</option>`).join("")}
              </select>
            </label>
            <button class="button primary" data-find-season type="button">${icons.plus} Tìm cả mùa</button>
          </div>
        </div>
        <div id="seasonSummary" class="season-summary"></div>
        <div id="episodeList" class="episode-list"><div class="library-loading">Đang tải danh sách tập…</div></div>
      </section>
    ` : ""}
  `;
}

function torrentSearchFromTitle(query) {
  elements.input.value = String(query || "").trim();
  state.page = 1;
  switchView("search", { instant: true });
  writeRoute({ view: "search", q: elements.input.value, source: state.source, page: 1 });
  search({ history: false });
}

function episodeCode(seasonNumber, episodeNumber) {
  return `S${String(seasonNumber).padStart(2, "0")}E${String(episodeNumber).padStart(2, "0")}`;
}

function renderSeason(season) {
  const summary = document.querySelector("#seasonSummary");
  const list = document.querySelector("#episodeList");
  if (!summary || !list) return;
  summary.innerHTML = `
    ${season.posterPath ? `<img src="${tmdbImage(season.posterPath, "w185")}" alt="" />` : ""}
    <div><h3>${escapeHtml(season.name)}</h3><p>${escapeHtml(season.overview || "Chưa có mô tả cho mùa này.")}</p></div>
  `;
  list.innerHTML = season.episodes.map((episode) => `
    <button class="episode-card" data-episode-number="${episode.episodeNumber}" type="button">
      <div class="episode-still">
        ${episode.stillPath ? `<img src="${tmdbImage(episode.stillPath, "w500")}" alt="" loading="lazy" />` : `<span>${episode.episodeNumber}</span>`}
        <i>${episode.episodeNumber}</i>
        <b>▶</b>
      </div>
      <div class="episode-copy">
        <div><strong>${escapeHtml(`${episode.episodeNumber}. ${episode.name}`)}</strong><span>${escapeHtml(formatRuntime(episode.runtime) || episode.airDate)}</span></div>
        <p>${escapeHtml(episode.overview || "Chưa có nội dung tiếng Việt hoặc tiếng Anh.")}</p>
        <small>Tìm ${escapeHtml(episodeCode(episode.seasonNumber, episode.episodeNumber))}</small>
      </div>
    </button>
  `).join("") || '<div class="notice">Mùa này chưa có danh sách tập.</div>';
}

async function loadTvSeason(tvId, seasonNumber, options = {}) {
  state.selectedSeason = Number(seasonNumber);
  const list = document.querySelector("#episodeList");
  if (list) list.innerHTML = '<div class="library-loading">Đang tải danh sách tập…</div>';
  if (options.updateRoute !== false) {
    const url = new URL(window.location.href);
    url.searchParams.set("season", String(state.selectedSeason));
    history.replaceState(
      { torrShelf: true, depth: Number(history.state?.depth) || 0 },
      "",
      url,
    );
  }
  try {
    const payload = await api(`/api/tmdb/tv/${tvId}/season/${state.selectedSeason}`);
    renderSeason(payload.data);
  } catch (error) {
    if (list) list.innerHTML = `<div class="notice">${escapeHtml(error.message)}</div>`;
  }
}

async function openMedia(item, options = {}) {
  if (!item) return;
  state.previousView = ["browse", "person"].includes(state.view) ? state.view : "discover";
  state.selectedMedia = item;
  state.selectedSeason = item.mediaType === "tv" && options.season != null
    ? Number(options.season)
    : null;
  switchView("media", { keepQuery: true, instant: true });
  if (options.history !== false) {
    writeRoute(
      { view: "media", type: item.mediaType, id: item.id, season: state.selectedSeason },
      { replace: options.replace },
    );
  }
  elements.mediaPageContent.innerHTML = "";
  elements.mediaPageLoading.classList.remove("hidden");
  try {
    const payload = await api(`/api/tmdb/${item.mediaType}/${item.id}`);
    state.selectedMedia = payload.data;
    state.mediaItems.set(mediaKey(payload.data), payload.data);
    if (payload.data.backdropPath) {
      elements.pageBackdropImage.src = tmdbImage(payload.data.backdropPath, "w1280");
      elements.pageBackdrop.classList.add("visible");
    }
    elements.mediaPageContent.innerHTML = renderMediaDetail(payload.data);
    if (payload.data.mediaType === "tv" && state.selectedSeason != null) {
      await loadTvSeason(payload.data.id, state.selectedSeason, { updateRoute: false });
    }
  } catch (error) {
    elements.mediaPageContent.innerHTML = `<div class="notice">${escapeHtml(error.message)}</div>`;
  } finally {
    elements.mediaPageLoading.classList.add("hidden");
  }
}

function renderPersonPage(person) {
  const gender = person.gender === 1 ? "Nữ" : person.gender === 2 ? "Nam" : "Không công bố";
  const aliases = person.alsoKnownAs.length
    ? `<div class="detail-tags">${person.alsoKnownAs.map((name) => `<span class="detail-tag">${escapeHtml(name)}</span>`).join("")}</div>`
    : "";
  const movieCredits = person.movieCredits || person.filmography.filter((item) => item.mediaType === "movie");
  const tvCredits = person.tvCredits || person.filmography.filter((item) => item.mediaType === "tv");
  const activeCredits = state.personTab === "tv" ? tvCredits : movieCredits;
  const pageSize = 14;
  const totalPages = Math.max(1, Math.ceil(activeCredits.length / pageSize));
  state.personPage = Math.min(totalPages, Math.max(1, state.personPage));
  const visibleCredits = activeCredits.slice((state.personPage - 1) * pageSize, state.personPage * pageSize);
  return `
    <article class="person-hero glass-panel">
      <div class="person-main-photo">${personPhoto(person, "w500")}</div>
      <div>
        <span class="dialog-kicker">${escapeHtml(person.knownForDepartment || "TMDB PERSON")}</span>
        <h1>${escapeHtml(person.name)}</h1>
        <div class="person-facts">
          ${person.birthday ? `<span>Sinh: ${escapeHtml(person.birthday)}</span>` : ""}
          ${person.deathday ? `<span>Mất: ${escapeHtml(person.deathday)}</span>` : ""}
          ${person.placeOfBirth ? `<span>${escapeHtml(person.placeOfBirth)}</span>` : ""}
          <span>${gender}</span>
        </div>
        <p class="person-biography">${escapeHtml(person.biography || "Chưa có tiểu sử tiếng Việt hoặc tiếng Anh cho nhân vật này.")}</p>
        ${aliases ? `<div class="detail-section"><div class="detail-section-head"><h2>Tên khác</h2></div>${aliases}</div>` : ""}
      </div>
    </article>
    <section class="person-filmography">
      <div class="detail-section-head">
        <h2>Filmography</h2>
        <span>${activeCredits.length} tựa</span>
      </div>
      <div class="person-credit-tabs">
        <button class="${state.personTab === "movie" ? "active" : ""}" data-person-tab="movie" type="button">Phim lẻ <i>${movieCredits.length}</i></button>
        <button class="${state.personTab === "tv" ? "active" : ""}" data-person-tab="tv" type="button">Phim bộ <i>${tvCredits.length}</i></button>
      </div>
      <div class="person-filmography-grid">
        ${visibleCredits.length ? visibleCredits.map(mediaCard).join("") : '<div class="notice">Chưa có tác phẩm trong nhóm này.</div>'}
      </div>
      <div class="browse-pagination">
        <button class="button ghost" data-person-page="${state.personPage - 1}" type="button" ${state.personPage <= 1 ? "disabled" : ""}>Trang trước</button>
        <span>Trang ${state.personPage} / ${totalPages}</span>
        <button class="button ghost" data-person-page="${state.personPage + 1}" type="button" ${state.personPage >= totalPages ? "disabled" : ""}>Trang sau</button>
      </div>
    </section>
  `;
}

async function openPerson(id, options = {}) {
  if (!id) return;
  state.previousView = state.view === "media" ? "media" : state.view === "browse" ? "browse" : "discover";
  state.personTab = options.tab === "tv" ? "tv" : options.tab === "movie" ? "movie" : state.personTab;
  state.personPage = Number(options.page) > 0 ? Number(options.page) : 1;
  switchView("person", { instant: true });
  if (options.history !== false) {
    writeRoute(
      { view: "person", person: id, creditType: state.personTab, page: state.personPage },
      { replace: options.replace },
    );
  }
  elements.personContent.innerHTML = "";
  elements.personLoading.classList.remove("hidden");
  try {
    const payload = await api(`/api/tmdb/person/${id}`);
    state.selectedPerson = payload.data;
    for (const item of payload.data.filmography || []) state.mediaItems.set(mediaKey(item), item);
    elements.personContent.innerHTML = renderPersonPage(payload.data);
  } catch (error) {
    elements.personContent.innerHTML = `<div class="notice">${escapeHtml(error.message)}</div>`;
  } finally {
    elements.personLoading.classList.add("hidden");
  }
}

function clearTorrentContext() {
  state.torrentContext = null;
  sessionStorage.removeItem("torrshelf.torrentContext");
}

function rememberTorrentContext(item) {
  if (!item) return;
  state.torrentContext = {
    id: item.id,
    mediaType: item.mediaType,
    title: item.title,
    originalTitle: item.originalTitle,
    year: item.year,
    posterPath: item.posterPath,
    backdropPath: item.backdropPath,
  };
  sessionStorage.setItem("torrshelf.torrentContext", JSON.stringify(state.torrentContext));
}

function findMedia(item) {
  if (!item) return;
  rememberTorrentContext(item);
  torrentSearchFromTitle(item.searchQuery || `${item.originalTitle || item.title} ${item.year || ""}`.trim());
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { Accept: "application/json", ...(options.headers || {}) },
  });
  const payload = await response.json().catch(() => ({ error: "Phản hồi máy chủ không hợp lệ." }));
  if (!response.ok) {
    const error = new Error(payload.error || payload.message || `HTTP ${response.status}`);
    error.payload = payload;
    throw error;
  }
  return payload;
}

function toast(title, message, type = "success", timeout = 5200) {
  const node = document.createElement("div");
  node.className = `toast ${type}`;
  node.innerHTML = `
    <span class="toast-icon">${type === "error" ? "!" : "✓"}</span>
    <div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(message)}</p></div>
    <button type="button" aria-label="Đóng">×</button>
  `;
  const remove = () => node.remove();
  node.querySelector("button").addEventListener("click", remove);
  elements.toastRegion.append(node);
  setTimeout(remove, timeout);
}

function setSource(source, trigger = true) {
  state.source = source;
  $$(".source-tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.source === source);
  });
  if (trigger && state.query) {
    state.page = 1;
    search();
  }
}

function showSkeletons() {
  elements.skeletons.innerHTML = Array.from({ length: 6 }, () => '<div class="skeleton-card"></div>').join("");
  elements.skeletons.classList.remove("hidden");
  elements.results.innerHTML = "";
  elements.empty.classList.add("hidden");
  elements.pagination.classList.add("hidden");
  elements.notice.classList.add("hidden");
  elements.header.classList.remove("hidden");
  elements.kicker.textContent = "ĐANG QUÉT HAI NGUỒN";
  elements.title.textContent = `“${state.query}”`;
  elements.meta.textContent = "Đang kết nối API…";
}

function sourceBadges(result) {
  return result.sources
    .map((source) => `<span class="source-badge ${source}">${source === "magnetz" ? "Magnetz" : "Knaben"}</span>`)
    .join("");
}

function resultCard(result) {
  const isAdded = result.infoHash && state.libraryHashes.has(result.infoHash.toUpperCase());
  const detailsUrl = safeExternalUrl(result.detailsUrl);
  return `
    <article class="result-card" data-ref="${escapeHtml(result.ref)}">
      <div class="card-top">
        <div class="card-tags">
          ${sourceBadges(result)}
          ${result.verified ? `<span class="verified-badge">${icons.verified} verified</span>` : ""}
        </div>
        <span class="card-origin" title="${escapeHtml(result.origin)}">${escapeHtml(result.origin)}</span>
      </div>
      <h3 title="${escapeHtml(result.title)}">${escapeHtml(result.title)}</h3>
      <div class="card-stat-row">
        <span class="card-stat">${icons.database}<strong>${escapeHtml(result.humanSize || formatBytes(result.size))}</strong></span>
        <span class="card-stat seeders">${icons.users}<strong>${Number(result.seeders).toLocaleString("vi-VN")}</strong> seed</span>
        <span class="card-stat"><strong>${Number(result.leechers).toLocaleString("vi-VN")}</strong> leech</span>
        <span class="category-badge" title="${escapeHtml(result.category)}">${escapeHtml(result.category || "Torrent")}</span>
      </div>
      <div class="card-bottom">
        <span class="card-date">${escapeHtml(formatDate(result.date))}</span>
        <div class="card-actions">
          <button class="icon-button" data-action="copy" type="button" aria-label="Sao chép magnet" title="Sao chép magnet">${icons.copy}</button>
          ${detailsUrl !== "#" ? `<a class="icon-button" href="${escapeHtml(detailsUrl)}" target="_blank" rel="noreferrer" aria-label="Mở trang nguồn" title="Mở trang nguồn">${icons.external}</a>` : ""}
          <button class="button ${isAdded ? "ghost added" : "primary"} add-button" data-action="add" type="button">
            ${isAdded ? `${icons.check}<span>Đã có</span>` : `${icons.plus}<span>Gửi TorrServer</span>`}
          </button>
        </div>
      </div>
    </article>
  `;
}

function renderResults(payload) {
  state.results = payload.data || [];
  state.maxPages = payload.meta?.maxPages || 1;
  state.hasNextPage = Boolean(payload.meta?.hasNextPage);
  elements.skeletons.classList.add("hidden");
  elements.header.classList.remove("hidden");
  elements.kicker.textContent = `${state.results.length} KẾT QUẢ ĐÃ LỌC`;
  elements.title.textContent = `“${payload.meta?.query || state.query}”`;

  const sourceTotal = Object.values(payload.meta?.sourceTotals || {}).reduce((sum, value) => sum + Number(value || 0), 0);
  elements.meta.innerHTML = `<strong>${sourceTotal.toLocaleString("vi-VN")}</strong> kết quả nguồn · ${payload.meta?.durationMs || 0} ms${payload.meta?.cached ? " · cache" : ""}`;

  const errors = payload.meta?.errors || [];
  if (errors.length) {
    elements.notice.textContent = errors.map((item) => `${item.source}: ${item.message}`).join(" · ");
    elements.notice.classList.remove("hidden");
  } else {
    elements.notice.classList.add("hidden");
  }

  if (!state.results.length) {
    elements.results.innerHTML = "";
    elements.empty.classList.remove("hidden");
    elements.empty.querySelector("h2").textContent = "Không có bản nào qua bộ lọc";
    elements.empty.querySelector("p").textContent = "Thử tăng giới hạn dung lượng, giảm seed tối thiểu hoặc đổi từ khóa.";
  } else {
    elements.empty.classList.add("hidden");
    elements.results.innerHTML = state.results.map(resultCard).join("");
  }

  elements.pageLabel.textContent = `Trang ${state.page}`;
  elements.prev.disabled = state.page <= 1;
  elements.next.disabled = !state.hasNextPage;
  elements.pagination.classList.toggle("hidden", state.maxPages <= 1);
}

function renderSearchError(error) {
  elements.skeletons.classList.add("hidden");
  elements.results.innerHTML = "";
  elements.header.classList.remove("hidden");
  elements.kicker.textContent = "KHÔNG THỂ TÌM KIẾM";
  elements.title.textContent = `“${state.query}”`;
  elements.meta.textContent = "";
  elements.notice.textContent = error.message;
  elements.notice.classList.remove("hidden");
  elements.empty.classList.remove("hidden");
  elements.empty.querySelector("h2").textContent = "Nguồn tìm kiếm đang bận";
  elements.empty.querySelector("p").textContent = "Chờ một chút rồi thử lại. TorrShelf vẫn hoạt động độc lập với TorrServer.";
  elements.pagination.classList.add("hidden");
}

async function search(options = {}) {
  const query = elements.input.value.trim();
  if (query.length < 2) {
    elements.input.focus();
    toast("Thiếu từ khóa", "Nhập ít nhất 2 ký tự.", "error");
    return;
  }

  state.controller?.abort();
  state.controller = new AbortController();
  state.query = query;
  state.loading = true;
  showSkeletons();

  const params = new URLSearchParams({
    q: query,
    source: state.source,
    page: String(state.page),
    maxGb: elements.maxSize.value,
    minSeeds: elements.minSeeds.value || "0",
    sort: elements.sort.value,
    hideXxx: String(elements.hideXxx.checked),
  });

  if (options.history !== false) {
    writeRoute(
      {
        view: "search",
        q: query,
        source: state.source,
        page: state.page,
        maxGb: elements.maxSize.value,
        minSeeds: elements.minSeeds.value || "0",
        sort: elements.sort.value,
        hideXxx: String(elements.hideXxx.checked),
      },
      { replace: options.replace ?? true },
    );
  }

  try {
    const payload = await api(`/api/search?${params}`, { signal: state.controller.signal });
    renderResults(payload);
    if (state.page > 1) elements.header.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    if (error.name !== "AbortError") renderSearchError(error);
  } finally {
    state.loading = false;
  }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.append(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
}

async function addTorrent(result, button) {
  if (button.dataset.busy === "true") return;
  const original = button.innerHTML;
  button.dataset.busy = "true";
  button.disabled = true;
  button.innerHTML = '<i class="spinner"></i><span>Đang gửi…</span>';
  try {
    const payload = await api("/api/torrserver/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ref: result.ref, tmdb: state.torrentContext }),
    });
    if (result.infoHash) state.libraryHashes.add(result.infoHash.toUpperCase());
    button.className = "button ghost added add-button";
    button.innerHTML = `${icons.check}<span>Đã thêm</span>`;
    toast("Đã gửi sang TorrServer", payload.message || result.title);
    checkHealth();
  } catch (error) {
    button.innerHTML = original;
    button.disabled = false;
    toast("Không thêm được torrent", error.message, "error", 7500);
  } finally {
    button.dataset.busy = "false";
  }
}

async function checkHealth() {
  try {
    const health = await api("/api/health");
    state.health = health;
    // v0.5 migration: previous versions auto-filled this value; reset to true opt-in filtering.
    localStorage.removeItem("torrshelf.maxSizeGb");
    const savedMax = localStorage.getItem("torrshelf.sizeFilterGb") || "";
    if (!elements.maxSize.dataset.initialized) {
      elements.maxSize.value = savedMax;
      elements.maxSize.dataset.initialized = "true";
    }
    elements.limitText.textContent = elements.maxSize.value
      ? `tối đa ${elements.maxSize.value} GB`
      : "không giới hạn";
    elements.serverLink.href = health.torrServerPublicUrl;
    state.torrServerPublicUrl = health.torrServerPublicUrl || "http://127.0.0.1:8090";
    elements.serverDot.className = `status-dot ${health.torrServer.online ? "online" : "offline"}`;
    elements.serverLabel.textContent = health.torrServer.online
      ? `TorrServer ${health.torrServer.version}`
      : "TorrServer đang offline";
    elements.serverLink.title = health.torrServer.online
      ? "Mở TorrServer"
      : "Khởi động TorrServer tại địa chỉ đã cấu hình";
    if (health.torrServer.online) {
      loadLibrary(false);
      startLibraryPolling();
    }
    if (state.view === "discover" && !state.discoverLoaded) {
      if (health.tmdb?.configured) loadDiscover();
      else {
        elements.discoverLoading.classList.add("hidden");
        elements.tmdbSetup.classList.remove("hidden");
      }
    }
  } catch {
    elements.serverDot.className = "status-dot offline";
    elements.serverLabel.textContent = "Không kiểm tra được server";
  }
}

function parseTorrentMetadata(value) {
  try {
    const parsed = typeof value === "string" ? JSON.parse(value) : value;
    return parsed?.TorrShelf || {};
  } catch {
    return {};
  }
}

function isVideoFile(path) {
  return /\.(mp4|m4v|mkv|webm|avi|mov|ts|m2ts|wmv|flv|mpg|mpeg)$/i.test(path || "");
}

function normalizeLibraryTorrent(torrent) {
  const metadata = parseTorrentMetadata(torrent.data);
  const tmdb = metadata.tmdb || null;
  const files = (torrent.file_stats || []).map((file) => ({
    id: Number(file.id),
    path: String(file.path || ""),
    length: Number(file.length) || 0,
    isVideo: isVideoFile(file.path),
  })).sort((a, b) => Number(b.isVideo) - Number(a.isVideo) || b.length - a.length);
  return {
    ...torrent,
    hash: String(torrent.hash || "").toLowerCase(),
    displayTitle: tmdb?.title || torrent.title || torrent.name || "Không tên",
    metadata,
    tmdb,
    files,
    posterPath: tmdb?.posterPath || "",
    backdropPath: tmdb?.backdropPath || "",
  };
}

function torrentProgress(torrent) {
  const preloadTotal = Number(torrent.preload_size) || 0;
  const preloadDone = Number(torrent.preloaded_bytes) || 0;
  const total = preloadTotal || Number(torrent.torrent_size) || 0;
  const done = preloadTotal ? preloadDone : Number(torrent.loaded_size) || 0;
  const percent = total > 0 ? Math.min(100, Math.max(0, done / total * 100)) : 0;
  return { done, total, percent, mode: preloadTotal ? "Preload" : "Loaded" };
}

function formatRate(value) {
  const bytes = Number(value) || 0;
  return bytes > 0 ? `${formatBytes(bytes)}/s` : "0 B/s";
}

function torrentMetricMarkup(torrent) {
  const progress = torrentProgress(torrent);
  const peers = Number(torrent.active_peers) || 0;
  const totalPeers = Number(torrent.total_peers) || 0;
  const seeds = Number(torrent.connected_seeders) || 0;
  return `
    <div class="torrent-live-metrics" data-live-hash="${torrent.hash}">
      <div><span>Tải xuống</span><strong data-metric="download">${escapeHtml(formatRate(torrent.download_speed))}</strong></div>
      <div><span>Peer</span><strong data-metric="peers">${peers}/${totalPeers}</strong></div>
      <div><span>Seed</span><strong data-metric="seeds">${seeds}</strong></div>
      <div><span>${progress.mode}</span><strong data-metric="progress">${progress.percent.toFixed(1)}%</strong></div>
      <progress max="100" value="${progress.percent.toFixed(1)}"></progress>
    </div>
  `;
}

function libraryPoster(torrent, size = "w500") {
  return torrent.posterPath
    ? `<img src="${tmdbImage(torrent.posterPath, size)}" alt="Poster ${escapeHtml(torrent.displayTitle)}" loading="lazy" />`
    : `<span class="poster-placeholder">${icons.film}</span>`;
}

function libraryCard(torrent) {
  const videoCount = torrent.files.filter((file) => file.isVideo).length;
  return `
    <button class="library-poster-card" data-library-hash="${torrent.hash}" type="button">
      <div class="library-poster">${libraryPoster(torrent)}</div>
      <div class="library-card-copy">
        <h3 title="${escapeHtml(torrent.displayTitle)}">${escapeHtml(torrent.displayTitle)}</h3>
        <p>${escapeHtml(formatBytes(torrent.torrent_size))} · ${videoCount || torrent.files.length} file</p>
        <span>${escapeHtml(torrent.stat_string || "Đã lưu")}</span>
        ${torrentMetricMarkup(torrent)}
      </div>
    </button>
  `;
}

function manageTorrentCard(torrent) {
  const videoFiles = torrent.files.filter((file) => file.isVideo);
  const files = videoFiles.length ? videoFiles : torrent.files;
  const firstFile = files[0];
  return `
    <article class="manage-torrent" data-manage-hash="${torrent.hash}">
      <div class="manage-torrent-head">
        <div class="manage-state"><i class="state-${torrent.stat}"></i><span>${escapeHtml(torrent.stat_string || "Unknown")}</span></div>
        <div class="manage-title"><h2>${escapeHtml(torrent.displayTitle)}</h2><p>${escapeHtml(formatBytes(torrent.torrent_size))} · ${files.length} file · ${escapeHtml(torrent.hash.slice(0, 12))}</p></div>
      </div>
      ${torrentMetricMarkup(torrent)}
      <div class="manage-actions">
        <button class="button primary" data-manage-action="activate" type="button">Kích hoạt</button>
        ${firstFile ? `<button class="button ghost" data-manage-action="preload" data-file-id="${firstFile.id}" type="button">Preload</button>` : ""}
        <button class="button ghost" data-manage-action="drop" type="button">Đóng</button>
        <button class="button danger" data-manage-action="rem" type="button">Xóa</button>
      </div>
      <details class="manage-files" ${files.length <= 3 ? "open" : ""}>
        <summary>File / tập <span>${files.length}</span></summary>
        <div>
          ${files.map((file, index) => {
            const stream = streamUrlFor(torrent, file);
            return `<div class="manage-file">
              <i>${index + 1}</i>
              <div><strong>${escapeHtml(file.path.split("/").pop())}</strong><p>${escapeHtml(fileEpisodeLabel(file.path) || formatBytes(file.length))}</p></div>
              <button class="icon-button" data-manage-player="${file.id}" type="button" title="Mở player">▶</button>
              <a class="icon-button" href="${escapeHtml(stream)}" target="_blank" rel="noreferrer" title="Mở tab mới">↗</a>
            </div>`;
          }).join("")}
        </div>
      </details>
    </article>
  `;
}

function progressKey(hash, fileId) {
  return `torrshelf.progress.${hash}.${fileId}`;
}

function readProgress(hash, fileId) {
  try {
    return JSON.parse(localStorage.getItem(progressKey(hash, fileId)) || "null");
  } catch {
    return null;
  }
}

function getProgressEntries() {
  const entries = [];
  for (let index = 0; index < localStorage.length; index += 1) {
    const key = localStorage.key(index);
    if (!key?.startsWith("torrshelf.progress.")) continue;
    try {
      const item = JSON.parse(localStorage.getItem(key));
      if (item?.hash && item?.fileId && item.currentTime > 5 && (!item.duration || item.currentTime < item.duration - 15)) {
        entries.push(item);
      }
    } catch {
      // Ignore corrupt local progress records.
    }
  }
  return entries.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).slice(0, 12);
}

function continueCard(item) {
  const percent = item.duration ? Math.min(100, Math.max(0, item.currentTime / item.duration * 100)) : 0;
  return `
    <button class="continue-card" data-resume-hash="${escapeHtml(item.hash)}" data-resume-file="${item.fileId}" type="button">
      <div class="continue-art">
        ${item.posterPath ? `<img src="${tmdbImage(item.posterPath, "w300")}" alt="" />` : `<span class="poster-placeholder">${icons.film}</span>`}
        <i>▶</i>
      </div>
      <div><h3>${escapeHtml(item.torrentTitle || item.fileName)}</h3><p>${escapeHtml(item.fileName)}</p><progress max="100" value="${percent.toFixed(1)}"></progress></div>
    </button>
  `;
}

function renderContinueWatching() {
  // Library-style Continue Watching is intentionally disabled in the simplified manager UI.
  elements.continueSection.classList.add("hidden");
  elements.libraryContinueSection.classList.add("hidden");
  elements.continueRow.innerHTML = "";
  elements.libraryContinueRow.innerHTML = "";
}

function renderLibrary(torrents) {
  const normalized = torrents.map(normalizeLibraryTorrent);
  state.libraryItems = new Map(normalized.map((torrent) => [torrent.hash, torrent]));
  state.libraryHashes = new Set(normalized.map((torrent) => torrent.hash.toUpperCase()).filter(Boolean));
  elements.libraryPageLoading.classList.add("hidden");
  elements.libraryEmpty.classList.toggle("hidden", normalized.length > 0);
  elements.libraryGrid.innerHTML = normalized.map(manageTorrentCard).join("");
  renderContinueWatching();
}

async function loadLibrary(showErrors = true) {
  elements.libraryPageLoading.classList.remove("hidden");
  try {
    const payload = await api("/api/torrserver/torrents");
    renderLibrary(payload.data || []);
    if (state.results.length) elements.results.innerHTML = state.results.map(resultCard).join("");
    return [...state.libraryItems.values()];
  } catch (error) {
    elements.libraryPageLoading.classList.add("hidden");
    if (showErrors) toast("Không mở được thư viện", error.message, "error");
    return [];
  }
}

function updateLiveMetricNodes(torrent) {
  const progress = torrentProgress(torrent);
  const peers = Number(torrent.active_peers) || 0;
  const totalPeers = Number(torrent.total_peers) || 0;
  const seeds = Number(torrent.connected_seeders) || 0;
  document.querySelectorAll(`[data-live-hash="${torrent.hash}"]`).forEach((panel) => {
    const set = (name, value) => {
      const node = panel.querySelector(`[data-metric="${name}"]`);
      if (node) node.textContent = value;
    };
    set("download", formatRate(torrent.download_speed));
    set("peers", `${peers}/${totalPeers}`);
    set("seeds", String(seeds));
    set("progress", `${progress.percent.toFixed(1)}%`);
    const bar = panel.querySelector("progress");
    if (bar) bar.value = progress.percent;
  });
}

async function pollLibraryStats() {
  if (!state.health?.torrServer?.online) return;
  try {
    const payload = await api("/api/torrserver/torrents");
    for (const raw of payload.data || []) {
      const torrent = normalizeLibraryTorrent(raw);
      const existing = state.libraryItems.get(torrent.hash);
      state.libraryItems.set(torrent.hash, existing ? { ...existing, ...torrent } : torrent);
      updateLiveMetricNodes(torrent);
      if (state.selectedTorrent?.hash === torrent.hash) {
        state.selectedTorrent = { ...state.selectedTorrent, ...torrent };
      }
    }
  } catch {
    // Keep the last known values; the health indicator handles connection errors.
  }
}

function startLibraryPolling() {
  if (state.libraryPollTimer) return;
  state.libraryPollTimer = setInterval(pollLibraryStats, 2_500);
}

async function openLibrary(options = {}) {
  switchView("library", { instant: true });
  if (options.history !== false) writeRoute({ view: "manage" }, { replace: options.replace });
  await loadLibrary(true);
}

function fileEpisodeLabel(path) {
  const match = String(path).match(/S(\d{1,2})E(\d{1,3})/i);
  return match ? `Mùa ${Number(match[1])} · Tập ${Number(match[2])}` : "";
}

function renderLibraryItem(torrent) {
  const files = torrent.files.filter((file) => file.isVideo);
  const visibleFiles = files.length ? files : torrent.files;
  return `
    <article class="library-item-hero glass-panel">
      <div class="library-item-poster">${libraryPoster(torrent, "w300")}</div>
      <div>
        <span class="dialog-kicker">${torrent.tmdb?.mediaType === "tv" ? "SERIES" : "LOCAL TORRENT"}</span>
        <h1>${escapeHtml(torrent.displayTitle)}</h1>
        <p>${escapeHtml(formatBytes(torrent.torrent_size))} · ${visibleFiles.length} file · ${escapeHtml(torrent.stat_string || "Đã lưu")}</p>
        ${torrentMetricMarkup(torrent)}
        <div class="detail-actions">
          ${visibleFiles[0] ? `<button class="button primary" data-play-file="${visibleFiles[0].id}" type="button">▶ Phát ngay</button>` : ""}
          <button class="button ghost" data-torrent-action="activate" type="button">Kích hoạt</button>
          ${visibleFiles[0] ? `<button class="button ghost" data-torrent-action="preload" data-file-id="${visibleFiles[0].id}" type="button">Preload</button>` : ""}
          <button class="button ghost" data-torrent-action="drop" type="button">Đóng cache</button>
          <button class="button danger" data-torrent-action="rem" type="button">Xóa</button>
        </div>
      </div>
    </article>
    <section class="library-files">
      <div class="detail-section-head"><h2>Chọn file hoặc tập</h2><span>${visibleFiles.length} mục</span></div>
      <div class="library-file-list">
        ${visibleFiles.map((file, index) => `
          <button class="library-file" data-play-file="${file.id}" type="button">
            <i>${index + 1}</i>
            <div><strong>${escapeHtml(file.path.split("/").pop())}</strong><p>${escapeHtml(fileEpisodeLabel(file.path) || file.path)}</p></div>
            <span>${escapeHtml(formatBytes(file.length))}</span>
            <b>▶</b>
          </button>
        `).join("")}
      </div>
    </section>
  `;
}

async function openLibraryItem(hash, options = {}) {
  const normalizedHash = String(hash || "").toLowerCase();
  if (!state.libraryItems.has(normalizedHash)) await loadLibrary(false);
  const torrent = state.libraryItems.get(normalizedHash);
  if (!torrent) return toast("Không tìm thấy torrent", "Torrent có thể đã bị xóa.", "error");
  state.selectedTorrent = torrent;
  switchView("libraryItem", { instant: true });
  if (options.history !== false) writeRoute({ view: "libraryItem", hash: normalizedHash }, { replace: options.replace });
  elements.libraryItemContent.innerHTML = renderLibraryItem(torrent);
}

function streamUrlFor(torrent, file) {
  return `${state.torrServerPublicUrl.replace(/\/$/, "")}/play/${encodeURIComponent(torrent.hash)}/${encodeURIComponent(file.id)}`;
}

function vlcIntentUrl(streamUrl) {
  try {
    const url = new URL(streamUrl);
    return `intent://${url.host}${url.pathname}${url.search}#Intent;scheme=${url.protocol.replace(":", "")};package=org.videolan.vlc;type=video/*;end`;
  } catch {
    return `vlc://${streamUrl}`;
  }
}

function savePlayerProgress(force = false) {
  const video = elements.videoPlayer;
  if (!state.selectedTorrent || !state.selectedFile || !Number.isFinite(video.currentTime)) return;
  const now = Date.now();
  if (!force && now - state.lastProgressSave < 4_000) return;
  state.lastProgressSave = now;
  const record = {
    hash: state.selectedTorrent.hash,
    fileId: state.selectedFile.id,
    fileName: state.selectedFile.path.split("/").pop(),
    torrentTitle: state.selectedTorrent.displayTitle,
    posterPath: state.selectedTorrent.posterPath,
    currentTime: video.currentTime,
    duration: Number.isFinite(video.duration) ? video.duration : 0,
    updatedAt: now,
  };
  localStorage.setItem(progressKey(record.hash, record.fileId), JSON.stringify(record));
  renderContinueWatching();
}

async function playTorrentFile(torrent, file, options = {}) {
  if (!torrent || !file) return;
  state.selectedTorrent = torrent;
  state.selectedFile = file;
  switchView("player", { instant: true });
  if (options.history !== false) {
    writeRoute({ view: "player", hash: torrent.hash, file: file.id }, { replace: options.replace });
  }
  const streamUrl = streamUrlFor(torrent, file);
  elements.playerTitle.textContent = torrent.displayTitle;
  elements.playerSubtitle.textContent = fileEpisodeLabel(file.path) || formatBytes(file.length);
  elements.playerFileName.textContent = file.path.split("/").pop();
  elements.playerError.classList.add("hidden");
  elements.openDirectStream.href = streamUrl;
  elements.openVlc.href = vlcIntentUrl(streamUrl);
  elements.videoPlayer.poster = torrent.backdropPath ? tmdbImage(torrent.backdropPath, "w1280") : "";
  elements.videoPlayer.src = streamUrl;
  elements.videoPlayer.load();
  elements.videoPlayer.play().catch(() => {
    // Browsers may require a second explicit tap; native controls stay visible.
  });
}

function debounce(fn, wait) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

const refreshForFilter = debounce(() => {
  if (!state.query) return;
  state.page = 1;
  search();
}, 350);

$$(".nav-button").forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.view === "search") goSearchView({ focusSearch: true });
    else if (button.dataset.view === "manage") openLibrary();
    else goDiscover();
  });
});

elements.discoverView.addEventListener("click", (event) => {
  const browseButton = event.target.closest("[data-browse-key]");
  if (browseButton) return openBrowse(browseButton.dataset.browseKey, 1);
  const findButton = event.target.closest("[data-find-media]");
  if (findButton) return findMedia(state.mediaItems.get(findButton.dataset.findMedia));
  const openButton = event.target.closest("[data-open-media]");
  if (openButton) openMedia(state.mediaItems.get(openButton.dataset.openMedia));
});

elements.tmdbSearchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  openTmdbSearch(elements.tmdbSearchInput.value, 1);
});

elements.browseGrid.addEventListener("click", (event) => {
  const openButton = event.target.closest("[data-open-media]");
  if (openButton) openMedia(state.mediaItems.get(openButton.dataset.openMedia));
});
elements.browsePeopleGrid.addEventListener("click", (event) => {
  const personButton = event.target.closest("[data-person-id]");
  if (personButton) openPerson(Number(personButton.dataset.personId));
});
function goBackOrDiscover() {
  if ((Number(history.state?.depth) || 0) > 0) history.back();
  else goDiscover({ replace: true });
}
elements.browseBackButton.addEventListener("click", goBackOrDiscover);
async function changeBrowsePage(page) {
  const url = new URL(window.location.href);
  url.searchParams.set("page", String(page));
  const depth = (Number(history.state?.depth) || 0) + 1;
  history.pushState({ torrShelf: true, depth }, "", url);
  await loadCurrentBrowse(page);
}
elements.browsePrev.addEventListener("click", () => {
  if (state.browsePage > 1) changeBrowsePage(state.browsePage - 1);
});
elements.browseNext.addEventListener("click", () => {
  if (state.browsePage < state.browseTotalPages) changeBrowsePage(state.browsePage + 1);
});
elements.mediaBackButton.addEventListener("click", goBackOrDiscover);
elements.mediaPageContent.addEventListener("change", (event) => {
  if (event.target.matches("#seasonSelect") && state.selectedMedia) {
    loadTvSeason(state.selectedMedia.id, Number(event.target.value));
  }
});
elements.mediaPageContent.addEventListener("click", (event) => {
  if (event.target.closest("[data-detail-find]")) return findMedia(state.selectedMedia);
  if (event.target.closest("[data-find-season]") && state.selectedMedia) {
    rememberTorrentContext(state.selectedMedia);
    const base = state.selectedMedia.originalTitle || state.selectedMedia.title;
    return torrentSearchFromTitle(`${base} Season ${state.selectedSeason}`);
  }
  const episodeButton = event.target.closest("[data-episode-number]");
  if (episodeButton && state.selectedMedia) {
    rememberTorrentContext(state.selectedMedia);
    const base = state.selectedMedia.originalTitle || state.selectedMedia.title;
    return torrentSearchFromTitle(
      `${base} ${episodeCode(state.selectedSeason, Number(episodeButton.dataset.episodeNumber))}`,
    );
  }
  const personButton = event.target.closest("[data-person-id]");
  if (personButton) return openPerson(Number(personButton.dataset.personId));
  const filterButton = event.target.closest("[data-discover-kind]");
  if (filterButton) {
    return openDiscoverFilter(
      filterButton.dataset.discoverKind,
      Number(filterButton.dataset.discoverId),
      filterButton.dataset.discoverLabel,
      filterButton.dataset.discoverMedia,
      1,
    );
  }
});
elements.personContent.addEventListener("click", (event) => {
  const tabButton = event.target.closest("[data-person-tab]");
  if (tabButton && state.selectedPerson) {
    state.personTab = tabButton.dataset.personTab;
    state.personPage = 1;
    elements.personContent.innerHTML = renderPersonPage(state.selectedPerson);
    writeRoute({ view: "person", person: state.selectedPerson.id, creditType: state.personTab, page: 1 });
    return;
  }
  const pageButton = event.target.closest("[data-person-page]");
  if (pageButton && !pageButton.disabled && state.selectedPerson) {
    state.personPage = Number(pageButton.dataset.personPage) || 1;
    elements.personContent.innerHTML = renderPersonPage(state.selectedPerson);
    writeRoute({ view: "person", person: state.selectedPerson.id, creditType: state.personTab, page: state.personPage });
    window.scrollTo({ top: elements.personContent.offsetTop, behavior: "smooth" });
    return;
  }
  const openButton = event.target.closest("[data-open-media]");
  if (openButton) openMedia(state.mediaItems.get(openButton.dataset.openMedia));
});
elements.personBackButton.addEventListener("click", goBackOrDiscover);

elements.setupSearchButton.addEventListener("click", () => goSearchView({ focusSearch: true }));

elements.form.addEventListener("submit", (event) => {
  event.preventDefault();
  clearTorrentContext();
  state.page = 1;
  search({ replace: false });
});

$$(".source-tab").forEach((button) => {
  button.addEventListener("click", () => setSource(button.dataset.source));
});

$$("[data-query]").forEach((button) => {
  button.addEventListener("click", () => {
    clearTorrentContext();
    elements.input.value = button.dataset.query;
    state.page = 1;
    search({ replace: false });
  });
});

elements.maxSize.addEventListener("change", () => {
  const raw = elements.maxSize.value.trim();
  if (!raw) {
    localStorage.removeItem("torrshelf.sizeFilterGb");
    elements.limitText.textContent = "không giới hạn";
  } else {
    const value = Math.max(1, Number(raw) || 1);
    elements.maxSize.value = String(value);
    elements.limitText.textContent = `tối đa ${value} GB`;
    localStorage.setItem("torrshelf.sizeFilterGb", String(value));
  }
  refreshForFilter();
});
[elements.sort, elements.hideXxx].forEach((control) => {
  control.addEventListener("change", refreshForFilter);
});
elements.minSeeds.addEventListener("input", refreshForFilter);

elements.results.addEventListener("click", (event) => {
  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) return;
  const card = actionButton.closest("[data-ref]");
  const result = state.results.find((item) => item.ref === card?.dataset.ref);
  if (!result) return;
  if (actionButton.dataset.action === "copy") {
    copyText(result.link).then(() => toast("Đã sao chép", "Magnet đã nằm trong clipboard."));
  } else if (actionButton.dataset.action === "add") {
    addTorrent(result, actionButton);
  }
});

elements.prev.addEventListener("click", () => {
  if (state.page <= 1 || state.loading) return;
  state.page -= 1;
  search({ replace: false });
});

elements.next.addEventListener("click", () => {
  if (!state.hasNextPage || state.loading) return;
  state.page += 1;
  search({ replace: false });
});

elements.libraryBackButton.addEventListener("click", goBackOrDiscover);
elements.libraryItemBackButton.addEventListener("click", goBackOrDiscover);
elements.playerBackButton.addEventListener("click", goBackOrDiscover);
elements.libraryRefreshButton.addEventListener("click", () => loadLibrary(true));

elements.libraryGrid.addEventListener("click", (event) => {
  const row = event.target.closest("[data-manage-hash]");
  if (!row) return;
  const torrent = state.libraryItems.get(row.dataset.manageHash);
  if (!torrent) return;
  const playerButton = event.target.closest("[data-manage-player]");
  if (playerButton) {
    const file = torrent.files.find((item) => item.id === Number(playerButton.dataset.managePlayer));
    if (file) playTorrentFile(torrent, file);
    return;
  }
  const actionButton = event.target.closest("[data-manage-action]");
  if (actionButton) {
    state.selectedTorrent = torrent;
    manageSelectedTorrent(
      actionButton.dataset.manageAction,
      Number(actionButton.dataset.fileId) || 0,
    );
  }
});

async function manageSelectedTorrent(action, fileId = 0) {
  if (!state.selectedTorrent) return;
  if (action === "rem" && !window.confirm(`Xóa “${state.selectedTorrent.displayTitle}” khỏi thư viện?`)) return;
  try {
    const payload = await api("/api/torrserver/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, hash: state.selectedTorrent.hash, fileId }),
    });
    const labels = {
      rem: "Đã xóa torrent",
      drop: "Đã đóng cache",
      activate: "Torrent đã được kích hoạt",
      preload: "Đã bắt đầu preload",
    };
    toast(labels[action] || "Đã cập nhật", state.selectedTorrent.displayTitle);
    if (action === "rem") {
      await openLibrary({ replace: true });
      return;
    }
    if (payload.torrent) {
      const merged = normalizeLibraryTorrent({ ...state.selectedTorrent, ...payload.torrent });
      state.selectedTorrent = merged;
      state.libraryItems.set(merged.hash, merged);
    }
    await loadLibrary(false);
    const refreshed = state.libraryItems.get(state.selectedTorrent.hash);
    if (refreshed) state.selectedTorrent = refreshed;
    if (state.view === "libraryItem" && state.selectedTorrent) {
      elements.libraryItemContent.innerHTML = renderLibraryItem(state.selectedTorrent);
    }
  } catch (error) {
    toast("Không thực hiện được", error.message, "error");
  }
}

elements.libraryItemContent.addEventListener("click", (event) => {
  const playButton = event.target.closest("[data-play-file]");
  if (playButton && state.selectedTorrent) {
    const file = state.selectedTorrent.files.find((item) => item.id === Number(playButton.dataset.playFile));
    if (file) playTorrentFile(state.selectedTorrent, file);
    return;
  }
  const actionButton = event.target.closest("[data-torrent-action]");
  if (actionButton) {
    manageSelectedTorrent(
      actionButton.dataset.torrentAction,
      Number(actionButton.dataset.fileId) || 0,
    );
  }
});

async function resumeProgress(event) {
  const button = event.target.closest("[data-resume-hash]");
  if (!button) return;
  const hash = button.dataset.resumeHash;
  const fileId = Number(button.dataset.resumeFile);
  if (!state.libraryItems.has(hash)) await loadLibrary(false);
  const torrent = state.libraryItems.get(hash);
  const file = torrent?.files.find((item) => item.id === fileId);
  if (torrent && file) playTorrentFile(torrent, file);
  else toast("Không thể xem tiếp", "Torrent hoặc file không còn trong thư viện.", "error");
}

elements.continueRow.addEventListener("click", resumeProgress);
elements.libraryContinueRow.addEventListener("click", resumeProgress);

elements.videoPlayer.addEventListener("loadedmetadata", () => {
  const record = state.selectedTorrent && state.selectedFile
    ? readProgress(state.selectedTorrent.hash, state.selectedFile.id)
    : null;
  if (record?.currentTime > 5 && record.currentTime < elements.videoPlayer.duration - 10) {
    elements.videoPlayer.currentTime = record.currentTime;
  }
});
elements.videoPlayer.addEventListener("timeupdate", () => savePlayerProgress(false));
elements.videoPlayer.addEventListener("pause", () => savePlayerProgress(true));
elements.videoPlayer.addEventListener("ended", () => {
  if (state.selectedTorrent && state.selectedFile) {
    localStorage.removeItem(progressKey(state.selectedTorrent.hash, state.selectedFile.id));
    renderContinueWatching();
  }
});
elements.videoPlayer.addEventListener("error", () => {
  elements.playerError.textContent = "Trình duyệt không phát được codec này hoặc torrent chưa preload xong. Hãy thử VLC.";
  elements.playerError.classList.remove("hidden");
});

document.addEventListener("keydown", (event) => {
  if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
    event.preventDefault();
    if (state.view !== "search") goSearchView({ focusSearch: true });
    else elements.input.focus();
  }
});

async function restoreRoute(url = new URL(window.location.href)) {
  const requestedView = url.searchParams.get("view");
  const query = url.searchParams.get("q")?.trim();
  if (query || requestedView === "search") {
    switchView("search", { instant: true });
    elements.input.value = query || "";
    state.page = Number(url.searchParams.get("page")) || 1;
    setSource(url.searchParams.get("source") || "all", false);
    elements.maxSize.value = url.searchParams.get("maxGb") || "";
    elements.minSeeds.value = url.searchParams.get("minSeeds") || "1";
    elements.sort.value = url.searchParams.get("sort") || "seeders";
    elements.hideXxx.checked = url.searchParams.get("hideXxx") !== "false";
    if (query) await search({ history: false });
    return;
  }
  if (requestedView === "manage" || requestedView === "library") {
    await openLibrary({ history: false });
    return;
  }
  if (requestedView === "libraryItem" && /^[a-f0-9]{40}$/i.test(url.searchParams.get("hash") || "")) {
    await openLibraryItem(url.searchParams.get("hash"), { history: false });
    return;
  }
  if (
    requestedView === "player"
    && /^[a-f0-9]{40}$/i.test(url.searchParams.get("hash") || "")
    && /^\d+$/.test(url.searchParams.get("file") || "")
  ) {
    if (!state.libraryItems.size) await loadLibrary(false);
    const torrent = state.libraryItems.get(url.searchParams.get("hash").toLowerCase());
    const file = torrent?.files.find((item) => item.id === Number(url.searchParams.get("file")));
    if (torrent && file) await playTorrentFile(torrent, file, { history: false });
    else goDiscover({ history: false, instant: true });
    return;
  }
  if (requestedView === "browse" && url.searchParams.get("tmdbq")) {
    await openTmdbSearch(url.searchParams.get("tmdbq"), Number(url.searchParams.get("page")) || 1, { history: false });
    return;
  }
  if (requestedView === "browse" && url.searchParams.get("kind")) {
    await openDiscoverFilter(
      url.searchParams.get("kind"),
      Number(url.searchParams.get("id")),
      url.searchParams.get("label") || "Danh mục",
      url.searchParams.get("type") === "tv" ? "tv" : "movie",
      Number(url.searchParams.get("page")) || 1,
      { history: false },
    );
    return;
  }
  if (requestedView === "browse" && url.searchParams.get("category")) {
    await openBrowse(url.searchParams.get("category"), Number(url.searchParams.get("page")) || 1, { history: false });
    return;
  }
  if (requestedView === "person" && /^\d+$/.test(url.searchParams.get("person") || "")) {
    await openPerson(Number(url.searchParams.get("person")), {
      history: false,
      tab: url.searchParams.get("creditType"),
      page: Number(url.searchParams.get("page")) || 1,
    });
    return;
  }
  if (
    requestedView === "media"
    && ["movie", "tv"].includes(url.searchParams.get("type"))
    && /^\d+$/.test(url.searchParams.get("id") || "")
  ) {
    await openMedia({
      id: Number(url.searchParams.get("id")),
      mediaType: url.searchParams.get("type"),
      title: "Đang tải…",
    }, {
      history: false,
      season: url.searchParams.has("season") ? Number(url.searchParams.get("season")) : null,
    });
    return;
  }
  goDiscover({ history: false, instant: true });
}

history.replaceState({ torrShelf: true, depth: 0 }, "", window.location.href);
window.addEventListener("popstate", () => restoreRoute(new URL(window.location.href)));
restoreRoute(new URL(window.location.href));

checkHealth();
setInterval(checkHealth, 30_000);
